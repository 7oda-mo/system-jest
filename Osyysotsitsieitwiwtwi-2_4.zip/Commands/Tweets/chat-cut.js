const Pro = require(`pro.db`);
const { owners } = require(`${process.cwd()}/config`);

module.exports = {
  name: "chat-cuts",
  run: async (client, message, args) => {
    
    const db = Pro.get(`Allow - Command chat-cuts = [ ${message.guild.id} ]`);
    const allowedRole = message.guild.roles.cache.get(db);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);
    const isOwner = owners.includes(message.author.id);

    if (!isAuthorAllowed && message.author.id !== db && !isOwner) {
      return message.react(`❌`);
    }

    if (args[0] === "list") {
      const savedChannels = Pro.get(`chat-cuts_${message.guild.id}`);
      if (!savedChannels || savedChannels.length === 0) {
        return message.reply("**No channels are currently saved.**");
      }
      const channelList = savedChannels
        .map((channelId) => `<#${channelId}>`)
        .join(", ");
      return message.channel.send(`**Saved Channels:** ${channelList}`);
    }

    if (args[0] === "remove") {
      const channel =
        message.mentions.channels.first() ||
        message.guild.channels.cache.get(message.content.split(" ")[1]);

      if (!channel) {
        return message.reply("**يرجى ارفاق منشن الشات او الايدي .**");
      }

      const savedChannels = Pro.get(`chat-cuts_${message.guild.id}`) || [];
      const updatedChannels = savedChannels.filter((channelId) => channelId !== channel.id);
      Pro.set(`chat-cuts_${message.guild.id}`, updatedChannels);
      return message.react(`✅`);
    }

    let channel =
      message.mentions.channels.first() ||
      message.guild.channels.cache.get(message.content.split(" ")[1]);

    if (!channel) {
      return message.reply("**يرجى ارفاق منشن الشات او الايدي .**");
    }

    const savedChannels = Pro.get(`chat-cuts_${message.guild.id}`) || [];
    savedChannels.push(channel.id);
    Pro.set(`chat-cuts_${message.guild.id}`, savedChannels);
    message.react(`✅`);
  },
};
