const { Client, Collection, MessageAttachment, WebhookClient, Intents, MessageButton, MessageSelectMenu, MessageActionRow, MessageModal, Role, Modal, TextInputComponent } = require("discord.js");
const { owners } = require(`${process.cwd()}/config`);
const db = require(`pro.db`)

module.exports = {
    name: "setticket",
    description: "A simple ping command.",
    run: async (client, Message) => {
        const Image = db.get(`Image = [${Message.guild.id}]`)
        const Channel = db.get(`Channel = [${Message.guild.id}]`)
        const Role = db.get(`Role = [${Message.guild.id}]`)
        const Cat = db.get(`Cat = [${Message.guild.id}]`)
        if (!Cat || !Role || !Channel || !Image) return Message.reply({ content: `**يرجي تنصيب باقي اوامر التذكره ..**` })
        if (Message.author.bot) return;
        if (!owners.includes(Message.author.id)) return Message.react('❌');
        if (!Message.guild) return;
        
        const Emb = new MessageActionRow().addComponents(
          new MessageSelectMenu()
            .setCustomId(`M0`)
            .setOptions(
              { label: `أفتح تذكرتك.`, value: `M1`, description: `قم بفتح تذكره دعم فني` , emoji : `<:emoji_1:1184849552046555136>` },
              { label: `استفسارات .`, value: `M2`, description: `قم بفتح تذكره استفسارات` , emoji : `<:emoji_1:1184849552046555136>` },
            )
            .setPlaceholder("يرجي إختيار نوع التذكره")
        )
        Message.channel.send({ files: [Image] }).then(async () => {
          await Message.channel.send({ components: [Emb] })
        })
    }
}




