const { MessageEmbed } = require('discord.js');
const { prefix, owners } = require(`${process.cwd()}/config`);
const ms = require('ms');
const moment = require('moment');
const Data = require('pro.db');
const db = require('pro.db');
module.exports = {
  name: 'سجن',
  aliases: ['prison'],
  run: async (client, message) => {
    const Color = db.get(`Guild_Color = ${message.guild.id}`) || message.guild.me.displayHexColor || `#000000`;
    if (!Color) return;

    const Pro = require(`pro.db`);
    const allowDb = Pro.get(`Allow - Command prison = [ ${message.guild.id} ]`);
    const allowedRole = message.guild.roles.cache.get(allowDb);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);

    if (!isAuthorAllowed && message.author.id !== allowDb && !message.member.permissions.has('MUTE_MEMBERS')) {
      return message.react(`❌`);
    }

    let args = message.content.split(' ').slice(1);
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    var time = args[2];
    if (!time) time = '24h';

    if (!member) {
      const embed = new MessageEmbed()
        .setColor(`${Color || message.guild.me.displayHexColor || `#000000`}`)
        .setDescription(`**يرجى استعمال الأمر بالطريقة الصحيحة .\n${prefix}سجن <@${message.author.id}>**`);
      return message.reply({ embeds: [embed] });
    }

    if (member.id === message.member.id) return message.react('❌');
    if (message.member.roles.highest.position < member.roles.highest.position) return message.react('❌');

    let muteRole = message.guild.roles.cache.find((role) => role.name == 'prison');
    if (!muteRole) {
      message.guild.roles.create({
        name: 'prison',
      }).then((createRole) => {
        message.guild.channels.cache.filter((c) => c.type === 'GUILD_TEXT').forEach(c => {
          c.permissionOverwrites.edit(createRole, { SEND_MESSAGES: false, VIEW_CHANNEL: false });
        });
        message.guild.channels.cache.filter((c) => c.type === 'GUILD_VOICE').forEach(c => {
          c.permissionOverwrites.edit(createRole, { VIEW_CHANNEL: false });
        });
        message.react('♻️');
      });
    } else {
      message.guild.members.cache.get(member.id)?.roles.add(muteRole);
      message.react('✅');

      const logChannelName = 'log-prison-unprison';
      const logChannel = message.guild.channels.cache.find(channel => channel.name === logChannelName);

      if (logChannel) {
        const logEmbed = new MessageEmbed()
          .setColor('#4b6691')
          .setTitle('Prison')
          .setDescription(`**To :** ${member}\n**By :** ${message.author}\n**Message :** [**Jump to Message**](${message.url})\n**Un Prison At :** \`${moment().format('HH:mm')}\`\n\`\`\`Prison : not yet\`\`\` `)
          .setThumbnail('https://cdn.discordapp.com/attachments/1091536665912299530/1157860838833659985/B1DF7F1C-78BB-480C-BC93-C77AC0CC5231.png?ex=651a256f&is=6518d3ef&hm=6b2145a1536bbd35209f34f01471ca5cec7a2ca7950c5d3e85e0407ec384ad07&')
          .setTimestamp();

        logChannel.send({ embeds: [logEmbed] });
      }

      Data.set(`MutedMember_${member.id}`, 'True', ms(time));
    }
  }
};
